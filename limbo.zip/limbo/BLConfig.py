#•••••••••••••••••••••••••••••••••••••••••••••••
#      BL`378_project - Limbo v1.1.0 (87)
#•••••••••••••••••••••••••••••••••••••••••••••••

Token   = "b879059ee6e593c86b764d28247ee8cae786774e834193d29969de88e76a696c83ccb514d30a01c9d9b1b7a0cad7ca69"

Betting ={
        "Base Bet"             : 0.0001,

        "Target Multiplier"    :{
                                "Min": 6,
                                "Max": 6
                                },

        "Max Base Bet"         : 0,

        "Increase If Win"      : 0,
        "Increase If Lose"     : 1,
        "Reset If Profit"      : 0,
        "Reset If Lose"        : 0,
        "Reset If Win Streak"  : 1.2,
        "Reset If Lose Streak" : 0,

        "Target Balance"       : 500
        }

Extra   ={
        "If Profit"            : 0,
        "If Lose"              : 1.2,
        
        "Action"               : "Sleep",  # Sleep or ReLogin
        "Delay"                : 60
        }

Bonus   ={
        "Status"                          : "on",
        "If Lose Streak"                  : 0,
        "Repeat Bets"                     : 6,
        "Increase Bet Amount After Repeat": 1.3
        
        # After max Number Repeats is reached,
        # Bet will continue with increasing bet amount
        # using Increase Bet Amount After Repeat
        }

#•••••••••••••••••••••••••••••••••••••••••••••••
#
#  Best Regards:
#
#  • Kapal Api Special MIX
#  • semua admin #Taraje_
#  • semua admin Bahu Jalan
#  • @prasun_parate untuk fungsi Fibonacci
#  • ~RcX untuk beberapa fungsi yang saya gunakan
#  • Siapapun Anda dg Dukungannya
#  • and All Source Providers
#  •••••
#
#  #bancetz.Laut_
#  @ballataxart  (tg)
#  378bancetz.laut@gmail.com
#•••••••••••••••••••••••••••••••••••••••••••••••